//Write your router code here!
// setup GET  for /recipes, response need to be { success: Boolean, payload: recipe array }
import express from "express";
const router = express.Router();

import recipes from '../libs/recipes.js';
//Iporting functions 
import {
  getRecipes,
  getRecipeByID,
  createRecipe,
  updateRecipeByID,
  deleteRecipeByID
} from '../models/recipes.js'

router.get("/", (req, res) => {
  // const responseObject= {
  //     success: true,
  //     payload: recipes 
  // }
  // res.json(responseObject)
  //----------------------------------
  res.json(getRecipes())
})

router.get("/:id", (req, res) => {
  // console.log(req.params)
  // let recipe =  recipes.find(recipe => recipe.id === parseInt(req.params.id));
  // console.log(recipe)
  // if(!recipe) return res.status(404).send("Data Not Found");
  // const responseObject = {success: true, payload: recipe};
  // res.json(responseObject)
  //----------------
  let id = parseInt(req.params.id);
  if (getRecipeByID(id) === "undefined") return res.status(404).send("Data Not Found");
  res.json(getRecipeByID(id))
})

router.post("/", (req, res) => {
  // let body = req.body;
  // let id = recipes.length + 1;
  // if(!body) return res.status(404).send("No Data Added");
  // let recipe = {id: id,
  //               title:body.title,
  //               ingredients:body.ingredients,
  //               instructions:body.instructions,
  //               image: body.image
  //              };
  //   recipes.push(recipe);
  //   const responseObject = {success: true, payload: recipe};
  //   res.json(responseObject)
  //------------------------
  let body = req.body;
  if (!createRecipe(body) === "undefined") return res.status(404).send("No Data Added");
  res.json(createRecipe(body))
})


router.put("/:id", (req, res) => {
  // let id = parseInt(req.params.id);
  //   let body = req.body;
  //   console.log(body)
  //   let recipe = recipes.find(r => r.id === id);
  //   if(!recipe) return res.status(404).send("Data Not Found");
  //     recipe.id = id;
  //     recipe.title = body.title;
  //     recipe.ingredients = body.ingredients;
  //     recipe.instructions = body.instructions;
  //     recipe.image = body.image;

  //  const responseObject = {success: true, payload:recipe };
  //   res.json(responseObject)
  //----------------------------
  let id = parseInt(req.params.id);
  let body = req.body;
  // Is this way correct to return 404
  if (updateRecipeByID(id, body) === "undefined") return res.status(404).send("Data Not Found");
  res.json(updateRecipeByID(id, body))
})



router.delete("/:id", (req, res) => {
  // let id = parseInt(req.params.id)
  // const recipe = recipes.find(recipe=> recipe.id === id);
  // if(!recipe) return res.status(404).send("Data Not Found");

  // let index = recipes.indexOf(recipe);
  // recipes.splice(index,1);
  // console.log(recipes);

  // const responseObject = { success: Boolean, payload: recipe }
  // res.json(responseObject)
  //--------------------------
  let id = parseInt(req.params.id)
  if (deleteRecipeByID(id) === "undefined") return res.status(404).send("Data Not Found");
  res.json(deleteRecipeByID(id))
})
//============================================================================
//Codes below work with the second type of data recipes (object of objects)
//============================================================================
// router.get("/", function (req, res) {

//     const responseObject = {
//         success: true,
//         message: `search results for title string`,
//         data: recipes,
//     };
//     res.json(responseObject);
// });

// router.get("/:id", function (req, res) {

//     const id = Number(req.params.id);
//     let recipe = recipes[id];
//     if (recipe != null) {
//         res.json({
//             success: Boolean,
//             payload: recipe
//         });
//     } else {
//         res.status(404)
//         res.json({ error: 'Not found' });
//         return 
//     }
// });

// router.post("/", function (req, res) {
//     const body = req.body;
//     const id = Object.keys(recipes).length + 1
//     recipes[id] = body;
//     res.json({
//         success: Boolean,
//         payload: recipes
//     });
// });

// router.put("/:id", function (req, res) {

//     const id = Number(req.params.id);
//     const body = req.body;
//     console.log(body);
//     if( recipes[id] != null) {
//         recipes[id] = body;
//         res.json({
//             success: Boolean,
//             payload: body
//         });
//     } else {
//         res.status(404)
//         res.json({ error: 'Not found' });
//         return 
//     }
// });

// router.delete('/:id', function (req, res) {
//     const id = Number(req.params.id);
//     if( recipes[id] != null) {
//         delete recipes[id];
//         res.json({

//         });
//     } else {
//         res.status(404);
//         res.json({ error: 'Not found' });
//         return ;
//     }

// });
//------------------------------ codes below work with second type of data 

// router.get("/", (req,res)=>{
//      const responseObject={ success: Boolean, payload: recipes } 
//      res.json(responseObject)
//      //res.send(recipes)
// })

// router.get("/:id", (req,res)=>{
//     let id = parseInt(req.params.id);
//     let recipe = null;
//     if(recipes.hasOwnProperty(id)){
//        recipe = recipes[id]
//     }
//     if(!recipe) return res.status(404).send("Recipe not found");

//     const responseObject = { success: true, payload: recipe }
//     res.json(responseObject)
// })

// router.post("/", (req,res) => {
//     let body =req.body;
//     let id = Object.keys(recipes).length + 1;
//     if(!body) return res.status(404).send("No Data Added");

//     recipes[id]= body;
//     const responseObject = { success:true, payload: recipes}
//     res.json(responseObject)
// })

// router.put("/:id", (req,res)=>{
//     let id= req.params.id;
//     let body = req.body;
//     if(recipes[id] !== null){
//         recipes[id] = body;
//     }else return res.status(404).send("Data Not Found")

//    const responseObject = { success:true, payload: body}
//          res.json(responseObject)  
// })

// router.delete("/:id", (req,res)=>{
//     let id =  req.params.id;
//     if(recipes[id]){
//         delete recipes[id];
//     }
//     else return res.status(404).send("Data Not Found")
//     res.json({})
// })

//--------------Experiment with BATH------------------------
// router.get("/test/:ab/:cd", function (req, res) {
//     console.log(req.params.ab,req.params.cd )
//     res.json({ ok: 'Okkks' });
//     console.log(req.query.ef, req.query.gh)
//     return ;
// });
//-----------End Of Experiment with BATH------------------------
export default router;