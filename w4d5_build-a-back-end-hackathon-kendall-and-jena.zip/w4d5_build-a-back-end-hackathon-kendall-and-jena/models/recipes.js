import recipes from "../libs/recipes.js";

//Please check these functions 
// GET ALL RECIPES
export function getRecipes() {

    const responseObject = {
        success: true,
        payload: recipes
    }
    return responseObject
}

// GET A RECIPE BY ID
export function getRecipeByID(id) {
    let recipe = recipes.find(recipe => recipe.id === id);
    if (!recipe) return "undefined"
    let responseObject = {
        success: true,
        payload: recipe
    };
    return responseObject
}
// CREATE A RECIPE
export function createRecipe(newRecipe) {
    let id = recipes.length + 1;
    // Is this wau correct to check 404 in route file?
    if (!newRecipe) return "undefined"
    let recipe = {
        id: id,
        title: newRecipe.title,
        ingredients: newRecipe.ingredients,
        instructions: newRecipe.instructions,
        image: newRecipe.image
    };
    recipes.push(recipe);
    let responseObject = {
        success: true,
        payload: recipe
    };
    return responseObject

}

// UPDATE A RECIPE BY ID
export function updateRecipeByID(id, updatedRecipe) {
    let recipe = recipes.find(r => r.id === id);
    if (!recipe) return "undefined";
    recipe.id = id;
    recipe.title = updatedRecipe.title;
    recipe.ingredients = updatedRecipe.ingredients;
    recipe.instructions = updatedRecipe.instructions;
    recipe.image = updatedRecipe.image;

    let responseObject = {
        success: true,
        payload: recipe
    };
    return responseObject

}


// DELETE A RECIPE BY ID
export function deleteRecipeByID(id) {
    const recipe = recipes.find(recipe => recipe.id === id);
    if (!recipe) return "undefined";
    console.log(recipe)

    let index = recipes.indexOf(recipe);
    recipes.splice(index, 1);

    const responseObject = {
        success: true,
        payload: recipe
    }

    return responseObject

}