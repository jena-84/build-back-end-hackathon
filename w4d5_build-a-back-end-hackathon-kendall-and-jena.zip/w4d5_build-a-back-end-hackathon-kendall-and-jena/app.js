import express from "express";

import { html } from "./config.js";

const app = express();
const PORT = 3000;
import recipesRouter from './router/recipes.js'

let count = 0;
app.use('/api/recipes',(req, res, next)=>{
  console.log("Request Type: ",req.method)
  count ++;
  console.log("Count: ",count)
  next()
})

app.use(express.static("public"));
app.use(express.json());

app.use('/api/recipes', recipesRouter);
// to display json
app.set('json spaces', 2)


/* DO NOT CHANGE THIS ROUTE - it serves our front-end */
app.get("/", function (req, res) {
  res.sendFile(html);
});

app.listen(PORT, () => {
  console.log(`Listening on port ${PORT}`);
});
